﻿using System;
using System.Collections.Generic;
using System.Threading;

class HeavyWorker
{
  // declarations
  private Thread mSendNextThread; // worker thread
  private ManualResetEvent mWaitEvent;  // signal the thread to wake up
  private Queue<int> mQue;        // buffer of jobs

  // Initialisation logic
  public HeavyWorker()
  {
    mQue = new Queue<int>();
    mWaitEvent = new ManualResetEvent(false);

    mSendNextThread = new Thread(new ThreadStart(OnMyOwnThread));
    mSendNextThread.Name = "HeavyWorker";
    mSendNextThread.IsBackground = true;
    mSendNextThread.Start();
  }

  // monitor jobs
  private void OnMyOwnThread()
  {
    while (true)
    {
      if (mWaitEvent.WaitOne())
      {
        mWaitEvent.Reset();
        while (mQue.Count > 0)
        {
          this.DoWork();
          mWaitEvent.Reset();
        }
      }
    }
  }

  // queue more jobs
  public void MoreInput(int someInput)
  {
    lock (mQue)
    {
      Console.WriteLine("Adding " + someInput);
      mQue.Enqueue(someInput);
    }

    mWaitEvent.Set();
  }

  // Time consuming processing
  private void DoWork()
  {
    int? queObj = null;
    lock (mQue)
    {
      if (mQue.Count > 0)
      {
        queObj = mQue.Dequeue();
      }
    }

    if (queObj != null)
    {
      Console.WriteLine("Processing: " + queObj.ToString());
      // SIMULATE LONG PROCESSING
      Thread.Sleep(5000);
      Console.WriteLine("Processed");
      
    }
  }
}