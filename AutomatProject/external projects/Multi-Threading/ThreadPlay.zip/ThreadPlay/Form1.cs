﻿using System;
using System.Threading;
using System.Windows.Forms;

public partial class Form1 : Form
{
  private HeavyWorker hw = new HeavyWorker();
  public Form1()
  {
    InitializeComponent();
  }

  private void tenClick(object sender, EventArgs e)
  {
    for (int i = 0; i < 10; i++)
    {
      Thread t =
        new Thread(
          delegate()
          {
            hw.MoreInput(
              new Random(
                Thread.CurrentThread.ManagedThreadId
                ).Next()
            );
          }
        );
      t.Start();
    }
  }
}
